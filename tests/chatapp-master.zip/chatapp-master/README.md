# weallchat 
A web app to get a real time chat application with your friends
created a user authentication using passport.JS
implemented blocking user adding user using mongoose.JS


## Installation

npm install 
node app.js

## Usage

to be written by author soon

## srs

https://drive.google.com/file/d/1NXd2tlIaqZ3TkmUbpLD6ddNGMnJBkUIs/view?usp=sharing

## Demo
https://drive.google.com/file/d/179gi0xHbndTBn9mCzcpA-C2gW6SZPpH4/view?usp=drivesdk


## Apk file
https://drive.google.com/file/d/1-7pi7UO9cfIuStiDn8t6EklLFE1s_49K/view?usp=sharing

## Running
https://enigmatic-garden-84250.herokuapp.com/
or 
http://weallchat.ml/


## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to test as appropriate before pull request.

## License
open source software 
